/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import edu.wpi.first.wpilibj.command.Subsystem;
import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;


import frc.robot.Robot;
import frc.robot.RobotMap;
import frc.robot.commands.IntakeCommand;

public class Intake extends Subsystem {

  public final double INTAKEFLOORPRESET = 2.0;
  public final double INTAKEUPPRESET = 0.0; 

    //Motors
  private TalonSRX intakeMotor;

    //Variables
  private int P,I,D = 1;
  private double derivative, error, integral = 0;

  public final int talonTPR = 4069; //Full Encoder Rotation

  public Intake() {
    intakeMotor = new TalonSRX(RobotMap.INTAKE.getValue());// defining intake talonr

    Robot.initTalon(intakeMotor, false);

    Robot.initMasterDriveMotor(intakeMotor);
}

  @Override
  public void initDefaultCommand() {
    setDefaultCommand(new IntakeCommand());
  }

  public void executePIDToPosition(double desiredPosition)
  {
      
      while (getIntakePosition() != desiredPosition) {
          error = desiredPosition - getIntakePosition(); // Error = Target - Actual
          this.integral += (error*.02); // Integral is increased by the error*time (which is .02 seconds using normal IterativeRobot)
          derivative = (error - this.error) / .02;
          double elevatorValue = P*error + I*this.integral + D*derivative;
          intakeMotor.set(ControlMode.PercentOutput, elevatorValue);
      }
  }

  //Get Intake Encoder in Feet
  public double getIntakePosition() {
    return intakeMotor.getSensorCollection().getQuadraturePosition();
  }

  public void moveIntakeToFloorPreset() {
    executePIDToPosition(INTAKEFLOORPRESET);
  }

  public void moveIntakeToUpPreset() {
    executePIDToPosition(INTAKEUPPRESET);
  }

}
